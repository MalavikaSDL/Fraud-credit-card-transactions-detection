# Fraud Credit Card Transaction Detector

This is a ML model built using Logical regression and Random Forest Classifier Algorithms in python language that can detect credit card fraudulent transactions so that customers of the companies aren't charged for something they haven't purchased.